
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));






// Serve static files from the "public" directory
app.use(express.static('public'));

// Handle form submission
app.post('/submit', (req, res) => {
    const { name, email } = req.body;
    res.send(`Name: ${name}, Email: ${email}`);
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
