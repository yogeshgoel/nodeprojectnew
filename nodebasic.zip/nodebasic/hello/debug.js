console.log('thing one');
    debugger;