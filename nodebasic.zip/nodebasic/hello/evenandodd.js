const readline = require('node:readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question(`Enter a number`, num => {
    if(num%2===0){
        console.log(`${num} is even`);
    }else {
        console.log(`${num} is odd` );
    }
  
  rl.close();
});
