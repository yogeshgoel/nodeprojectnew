const square = (x) => {
    return x*x;

}

console.log(square(2));
