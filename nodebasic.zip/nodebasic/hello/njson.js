const book = {
    title : 'Ego is empty',
    author : "Royal"
}

const bookJSON = JSON.stringify(book);

const bookobject = JSON.parse(bookJSON);

console.log(bookobject.title);
console.log(bookobject.author);