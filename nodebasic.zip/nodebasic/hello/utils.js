const check = function () {
    console.log('doing some work....');
}

module.exports = check