console.log('Staring');

setTimeout(()=> {
  console.log('2 second timer');
}, 2000)

console.log('stopping');